<!<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viemport" content="width=device-width, initial-scale=1">
    <title>Chat App</title>

    <link rel="stylesheet" type="text/css" href="css/style.css">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/font-awesome.min.css">
</head>
const pwrdField = document.querySelector(".form input[type='password']"),
toggleIcon = document.querySelector(".form .field i");

toggleIcon.onclick =()=>{
    if(pwrdField.type ==="password")
    {
        pwrdField.type = "text";
        toggleIcon.classList.add("active");
    }else
    {
        pwrdField.type ==="password"
        toggleIcon.classList.remove("active");
    }
}